<?php
include_once 'setting.inc.php';

$_lang['cityselect'] = 'citySelect';
