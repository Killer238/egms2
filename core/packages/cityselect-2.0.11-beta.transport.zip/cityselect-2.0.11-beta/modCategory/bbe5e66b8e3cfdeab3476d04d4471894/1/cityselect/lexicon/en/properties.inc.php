<?php


$_lang['cityselect_prop_tpl'] = 'Чанк оформления';
$_lang['cityselect_prop_frontCss'] = 'Файл с css стилями для подключения на фронтенд.';
$_lang['cityselect_prop_frontJs'] = 'Файл с javascript для подключения на фронтенде.';
$_lang['cityselect_prop_actionUrl'] = 'Коннектор для обработки ajax запросов.';

$_lang['cityselect_prop_bootstrapModalJsCss'] = 'Подключить файлы bootstrap-modal.';
$_lang['cityselect_prop_bootstrapDialogJsCss'] = 'Подключить файлы bootstrap-dialog.';
$_lang['cityselect_prop_yandexMapsJsCss'] = 'Подключить файлы yandex maps.';
$_lang['cityselect_prop_bootstrapPopoverJsCss'] = 'Подключить файлы bootstrap-popover.';
$_lang['cityselect_prop_bootstrapTabJsCss'] = 'Подключить файлы bootstrap-tabs.';
$_lang['cityselect_prop_selectizeJsCss'] = 'Подключить файлы selectize.';

$_lang['cityselect_prop_bootstrapModalJs'] = 'Файл с bootstrap-modal.js для подключения на фронтенде.';
$_lang['cityselect_prop_bootstrapModalCss'] = 'Файл с bootstrap-modal.css для подключения на фронтенде.';
$_lang['cityselect_prop_bootstrapDialogJs'] = 'Файл с bootstrap-dialog.js для подключения на фронтенде.';
$_lang['cityselect_prop_bootstrapDialogCss'] = 'Файл с bootstrap-dialog.css для подключения на фронтенде.';
$_lang['cityselect_prop_bootstrapPopoverJs'] = 'Файл с bootstrap-popover.js для подключения на фронтенде.';
$_lang['cityselect_prop_bootstrapPopoverCss'] = 'Файл с bootstrap-popover.css для подключения на фронтенде.';
$_lang['cityselect_prop_bootstrapTabJs'] = 'Файл с bootstrap-tabs.js для подключения на фронтенде.';
$_lang['cityselect_prop_bootstrapTabCss'] = 'Файл с bootstrap-tabs.css для подключения на фронтенде.';
$_lang['cityselect_prop_selectizeJs'] = 'Файл с selectize.js для подключения на фронтенде.';
$_lang['cityselect_prop_selectizeCss'] = 'Файл с selectize.css для подключения на фронтенде.';
$_lang['cityselect_prop_yandexMapsJs'] = 'Файл с yandexMaps.js для подключения на фронтенде.';
$_lang['cityselect_prop_yandexMapsCss'] = 'Файл с yandexMaps.css для подключения на фронтенде.';
$_lang['cityselect_prop_processBlocks'] = 'JSON строка содержащая блоки необходимые для обработки.';
