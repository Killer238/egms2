<?php
$_lang['area_controlerrorlog.main'] = 'Main';

$_lang['setting_controlerrorlog.last_lines'] = 'Last lines';
$_lang['setting_controlerrorlog.last_lines_desc'] = 'Displays specified number of last lines, when the error log is too large to display.';
$_lang['setting_controlerrorlog.refresh_freq'] = 'Refresh frequency (sec)';
$_lang['setting_controlerrorlog.refresh_freq_desc'] = 'Error log refresh frequency in seconds.';
$_lang['setting_controlerrorlog.auto_refresh'] = 'Enable auto refresh';
$_lang['setting_controlerrorlog.auto_refresh_desc'] = 'On/off auto refresh of error log with specified frequency.';
$_lang['setting_controlerrorlog.control_frontend'] = 'Notify about changes';
$_lang['setting_controlerrorlog.control_frontend_desc'] = 'Control the error log and notify about changes.';
$_lang['setting_controlerrorlog.admin_email'] = 'Admin email';
$_lang['setting_controlerrorlog.admin_email_desc'] = 'Admin email to notify about changes in the error log.';
$_lang['setting_controlerrorlog.allow_copy_deletion'] = 'Enable deletion of copies';
$_lang['setting_controlerrorlog.allow_copy_deletion_desc'] = 'True - delete log copy. False - only clear the content.';