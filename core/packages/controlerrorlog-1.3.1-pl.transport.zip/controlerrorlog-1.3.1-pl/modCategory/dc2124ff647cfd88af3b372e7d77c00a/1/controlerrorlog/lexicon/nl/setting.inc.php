<?php
$_lang['area_controlerrorlog.main'] = 'Algemeen';

$_lang['setting_controlerrorlog.last_lines'] = 'Aantal regels die getoond worden indien foutlog te groot is';
$_lang['setting_controlerrorlog.last_lines_desc'] = 'Toont dit aantal regels indien het foutlog te groot is om weer te geven.';
$_lang['setting_controlerrorlog.refresh_freq'] = 'Vernieuwingsfrequentie (in seconden)';
$_lang['setting_controlerrorlog.refresh_freq_desc'] = 'Na hoeveel seconden de weergave van het foutlog automatisch moet worden ververst.';
$_lang['setting_controlerrorlog.auto_refresh'] = 'Automatisch vernieuwen';
$_lang['setting_controlerrorlog.auto_refresh_desc'] = 'Of het foutlog automatisch moet worden ververst na het gespecificeerd aantal seconden.';
$_lang['setting_controlerrorlog.control_frontend'] = 'Informeren over wijzigingen';
$_lang['setting_controlerrorlog.control_frontend_desc'] = 'Informeren over wijzigingen.';
$_lang['setting_controlerrorlog.admin_email'] = 'E-mailadres administrator';
$_lang['setting_controlerrorlog.admin_email_desc'] = 'Indien er iets in het foutlog wordt geschreven, zal er naar dit e-mailadres een notificatie worden verzonden.';
$_lang['setting_controlerrorlog.allow_copy_deletion'] = 'Enable deletion of copies';
$_lang['setting_controlerrorlog.allow_copy_deletion_desc'] = 'True - delete log copy. False - only clear the content.';