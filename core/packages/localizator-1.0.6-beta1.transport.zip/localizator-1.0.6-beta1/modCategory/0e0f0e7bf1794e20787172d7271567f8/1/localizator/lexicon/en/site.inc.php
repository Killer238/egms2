<?php

$_lang['test'] = 'Test';