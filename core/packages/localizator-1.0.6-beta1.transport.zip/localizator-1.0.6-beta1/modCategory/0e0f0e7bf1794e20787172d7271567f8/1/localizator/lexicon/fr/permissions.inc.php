<?php

$_lang['localizatorcontent_list'] = 'Permission de liste de localisations';
$_lang['localizatorcontent_view'] = 'Permission d\'afficher des localisations';
$_lang['localizatorcontent_save'] = 'Permission de sauvegarder\update\remove localizations';
