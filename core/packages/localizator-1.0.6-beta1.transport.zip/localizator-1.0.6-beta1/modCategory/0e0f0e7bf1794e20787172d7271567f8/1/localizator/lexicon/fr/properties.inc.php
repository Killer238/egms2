<?php

$_lang['localizator_prop_snippet'] = 'Extrait de code, qui s’appellera pour générer les résultats des travaux. Par défaut - «pdoResources»';
$_lang['localizator_prop_class'] = 'Objet. Par défaut - «modResource»';
$_lang['localizator_prop_localizatorTVs'] = 'La liste de la télévision des paramètres pour un échantillon de l’alignement de piste. La valeur par défaut est sélectionnée dans les préférences système';
$_lang['localizator_prop_localizator_key'] = 'Localisation de clés. La valeur par défaut correspond au courant';