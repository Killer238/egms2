<?php

$_lang['localizator_prop_snippet'] = 'Сниппет, который будет вызываться для вывода результатов работы. По-умолчанию - "pdoResources"';
$_lang['localizator_prop_class'] = 'Объект. По-умолчанию - "modResource"';
$_lang['localizator_prop_localizatorTVs'] = 'Список ТВ параметров для выборки из локализатора. По-умолчанию - выбранные в системных настройках';
$_lang['localizator_prop_localizator_key'] = 'Ключ локализации. По-умолчанию - текущий';