<?php

$_lang['test'] = 'Тест';