<?php
require_once (dirname(__DIR__) . '/localizatorcontent.class.php');
class localizatorContent_mysql extends localizatorContent {}