<?php

$_lang['area_modalconsole_main'] = 'Main';

$_lang['setting_modalconsole_history_limit'] = 'History limit';
$_lang['setting_modalconsole_history_limit_desc'] = 'Number of requests to save it the history. 0 - to disable saving the request history.';
$_lang['setting_modalconsole_cssUrl'] = 'Css file';
$_lang['setting_modalconsole_cssUrl_desc'] = 'Enter css file URL or leave the field empty to prevent his loading.';
$_lang['setting_modalconsole_jsUrl'] = 'Javascript file';
$_lang['setting_modalconsole_jsUrl_desc'] = 'Enter javascript file URL or leave the field empty to prevent his loading.';
$_lang['setting_modalconsole_enable'] = 'Enable the console';
$_lang['setting_modalconsole_enable_desc'] = 'Enable the console.';
$_lang['setting_modalconsole_files_path'] = 'Path to save files';
$_lang['setting_modalconsole_files_path_desc'] = 'Path to save files.';