<?php

$_lang['area_modalconsole_main'] = 'Основные';

$_lang['setting_modalconsole_history_limit'] = 'Количество запросов';
$_lang['setting_modalconsole_history_limit_desc'] = 'Укажите, какое количество запросов будет хранится в кэше. 0 - отключает сохранение истории.';
$_lang['setting_modalconsole_cssUrl'] = 'Файл стилей консоли';
$_lang['setting_modalconsole_cssUrl_desc'] = 'Укажите файл стилей или оставьте поле пустым, чтобы отключить его загрузку.';
$_lang['setting_modalconsole_jsUrl'] = 'Файл скриптов консоли';
$_lang['setting_modalconsole_jsUrl_desc'] = 'Укажите файл со скриптами или оставьте поле пустым, чтобы отключить его загрузку.';
$_lang['setting_modalconsole_enable'] = 'Включить консоль';
$_lang['setting_modalconsole_enable_desc'] = 'Включить консоль.';
$_lang['setting_modalconsole_files_path'] = 'Путь к файлам';
$_lang['setting_modalconsole_files_path_desc'] = 'Путь к сохранённым файлам.';