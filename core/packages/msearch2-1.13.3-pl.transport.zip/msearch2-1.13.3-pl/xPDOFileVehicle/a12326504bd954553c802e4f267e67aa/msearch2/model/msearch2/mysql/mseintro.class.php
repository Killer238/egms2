<?php
require_once (dirname(__DIR__) . '/mseintro.class.php');
class mseIntro_mysql extends mseIntro {}