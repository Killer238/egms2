<?php
require_once (dirname(__DIR__) . '/msealias.class.php');
class mseAlias_mysql extends mseAlias {}