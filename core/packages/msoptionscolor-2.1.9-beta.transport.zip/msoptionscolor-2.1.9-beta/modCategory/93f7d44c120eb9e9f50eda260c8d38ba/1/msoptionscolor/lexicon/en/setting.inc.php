<?php

$_lang['area_msoptionscolor_main'] = 'Основные';

$_lang['setting_msoptionscolor_working_templates'] = 'Активные шаблоны';
$_lang['setting_msoptionscolor_working_templates_desc'] = 'Список id шаблонов через запятую, для которых нужно активировать вкладку.';

$_lang['setting_msoptionscolor_grid_color_fields'] = 'Поля таблицы';
$_lang['setting_msoptionscolor_grid_color_fields_desc'] = 'Список полей таблицы через запятую.';

$_lang['setting_msoptionscolor_window_color_fields'] = 'Поля окна';
$_lang['setting_msoptionscolor_window_color_fields_desc'] = 'Список полей окна через запятую.';

$_lang['setting_msoptionscolor_create_colors_with_duplicate'] = 'Создавать цвета при копировани';
$_lang['setting_msoptionscolor_create_colors_with_duplicate_desc'] = 'Создавать цвета при копировани продукта.';

$_lang['setting_msoptionscolor_fill_colors_with_create'] = 'Заполнять цвета при создании';
$_lang['setting_msoptionscolor_fill_colors_with_create_desc'] = 'Заполнять цвета при создании из уже существующих.';

$_lang['setting_msoptionscolor_file_source'] = 'Источник файлов по умолчанию';
$_lang['setting_msoptionscolor_file_source_desc'] = 'Источник файлов для изображений по умолчанию.';

$_lang['setting_msoptionscolor_grid_color_show_possible'] = 'Показывать возможные значения';
$_lang['setting_msoptionscolor_grid_color_show_possible_desc'] = 'Показывать возможные значения опций для создания цвета.';

$_lang['setting_msoptionscolor_default_option_key'] = 'Опция по умолчанию';
$_lang['setting_msoptionscolor_default_option_key_desc'] = 'Ключ опции цвета по умолчанию.';