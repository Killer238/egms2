<?php

$_lang['msoptionscolor_prop_limit'] = 'Ограничение вывода Предметов на странице';
$_lang['msoptionscolor_prop_outputSeparator'] = 'Разделитель вывода строк';
$_lang['msoptionscolor_prop_sortBy'] = 'Поле сортировки';
$_lang['msoptionscolor_prop_sortDir'] = 'Направление сортировки';
$_lang['msoptionscolor_prop_tpl'] = 'Чанк оформления каждого ряда Предметов';
$_lang['msoptionscolor_prop_toPlaceholder'] = 'Усли указан этот параметр, то результат будет сохранен в плейсхолдер, вместо прямого вывода на странице';
$_lang['msoptionscolor_prop_where'] = 'Строка, закодированная в JSON, с дополнительными условиями выборки';
$_lang['msoptionscolor_prop_showLog'] = 'Показывать дополнительную информацию о работе сниппета. Только для авторизованных в контексте "mgr"';
$_lang['msoptionscolor_prop_returnIds'] = 'Возвращать строку с id обьектов, вместо оформленных чанков';
$_lang['msoptionscolor_prop_showEmptyColor'] = 'Показывать объекты с пустым цветом';
$_lang['msoptionscolor_prop_showEmptyPattern'] = 'Показывать объекты с пустым паттерном';
$_lang['msoptionscolor_prop_product'] = 'Идентификатор продукта. Если не указан, используется id текущего документа';
$_lang['msoptionscolor_prop_sortby'] = 'Сортировка выборки';
$_lang['msoptionscolor_prop_sortdir'] = 'Направление сортировки';
$_lang['msoptionscolor_prop_options'] = 'Опции продукта';