--------------------
msOptionsColor
--------------------
Author: Vgrish <vgrish@gmail.com>
--------------------
