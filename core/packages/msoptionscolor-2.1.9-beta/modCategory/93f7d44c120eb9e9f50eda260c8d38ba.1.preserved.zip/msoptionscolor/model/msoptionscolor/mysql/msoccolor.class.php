<?php
require_once (dirname(__DIR__) . '/msoccolor.class.php');
class msocColor_mysql extends msocColor {}