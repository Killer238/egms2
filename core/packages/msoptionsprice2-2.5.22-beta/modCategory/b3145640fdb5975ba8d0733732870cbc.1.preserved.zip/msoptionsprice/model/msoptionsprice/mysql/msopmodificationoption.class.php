<?php
require_once (dirname(__DIR__) . '/msopmodificationoption.class.php');
class msopModificationOption_mysql extends msopModificationOption {}