--------------------
msOrderAnalytics
--------------------
Author: Pavel Gvozdb <pavelgvozdb@yandex.ru>
--------------------

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/gvozdb/msOrderAnalytics/issues