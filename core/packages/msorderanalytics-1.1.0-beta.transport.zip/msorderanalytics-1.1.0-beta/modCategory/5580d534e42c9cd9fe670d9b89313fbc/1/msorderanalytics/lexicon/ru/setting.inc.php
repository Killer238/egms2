<?php

$_lang['area_msoa_main'] = 'Основные';

// Main
$_lang['setting_msoa_ga_tracking_id'] = 'Google Analytics ID';
$_lang['setting_msoa_ga_tracking_id_desc'] = 'Указывается в виде UA-XXXX-Y';

$_lang['setting_msoa_currency'] = 'Валюта магазина';
$_lang['setting_msoa_currency_desc'] = 'Валюта, в которой отсылать данные в GA';

$_lang['setting_msoa_shop_name'] = 'Название магазина';
$_lang['setting_msoa_shop_name_desc'] = 'Магазин для идентификации данных в GA. Можно использовать системные настройки: [[++site_name]]';
