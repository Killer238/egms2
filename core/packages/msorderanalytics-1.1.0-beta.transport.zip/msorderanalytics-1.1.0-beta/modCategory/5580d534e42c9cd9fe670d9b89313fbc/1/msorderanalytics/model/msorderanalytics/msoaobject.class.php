<?php
class msoaObject extends xPDOSimpleObject {}