<?php
require_once (dirname(dirname(__FILE__)) . '/msoaobject.class.php');
class msoaObject_mysql extends msoaObject {}