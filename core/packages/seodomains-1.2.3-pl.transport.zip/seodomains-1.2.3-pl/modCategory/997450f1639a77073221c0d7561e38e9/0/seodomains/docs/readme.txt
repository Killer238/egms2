--------------------
SeoDomains
--------------------
Author: Mikhail Tyrsyna <mikhail@tyrsyna.ru>
--------------------

Extra for MODx Revolution.