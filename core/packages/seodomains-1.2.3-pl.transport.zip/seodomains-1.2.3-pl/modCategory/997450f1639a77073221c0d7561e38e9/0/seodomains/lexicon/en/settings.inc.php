<?php

$_lang['area_seodomains_main'] = 'Main';
$_lang['area_seodomains_yandex'] = 'Yandex OAuth';
$_lang['area_seodomains_manager'] = 'Manager';

$_lang['setting_seodomains_default_email'] = 'Default E-mail';
$_lang['setting_seodomains_default_phone'] = 'Default Phone';
$_lang['setting_seodomains_html_parent'] = 'Parent HTML Resource to Verify Domain Rights';
$_lang['setting_seodomains_main_host'] = 'Primary host';
$_lang['setting_seodomains_main_host_desc'] = 'It will be redirected in the absence of a domain in the database. Example: http://test.com/';
$_lang['setting_seodomains_phx_prefix'] = 'Placeholder Prefix';
$_lang['setting_seodomains_token'] = 'Token';
$_lang['setting_seodomains_user_id'] = 'User_id';
$_lang['setting_seodomains_user_id_desc'] = 'Optionally, will be filled in automatically when you first add a domain';
$_lang['setting_seodomains_cyrillic_domain'] = 'Cyrillic domain?';
$_lang['setting_seodomains_city_fields'] = 'Grid fields';