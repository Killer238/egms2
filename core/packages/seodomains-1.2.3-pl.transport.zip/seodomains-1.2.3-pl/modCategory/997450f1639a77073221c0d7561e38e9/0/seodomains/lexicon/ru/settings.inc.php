<?php

$_lang['area_seodomains_main'] = 'Основные';
$_lang['area_seodomains_yandex'] = 'Яндекс OAuth';
$_lang['area_seodomains_manager'] = 'Менеджер';

$_lang['setting_seodomains_default_email'] = 'E-mail по умолчанию';
$_lang['setting_seodomains_default_phone'] = 'Телефон по умолчанию';
$_lang['setting_seodomains_html_parent'] = 'Родитель HTML ресурсов для подтверждения прав на домен';
$_lang['setting_seodomains_main_host'] = 'Основной хост';
$_lang['setting_seodomains_main_host_desc'] = 'На него будет происходить редирект при отсутствии домена в базе. Пример: http://test.ru/';
$_lang['setting_seodomains_phx_prefix'] = 'Префикс для плейсхолдеров';
$_lang['setting_seodomains_token'] = 'Token';
$_lang['setting_seodomains_user_id'] = 'User_id';
$_lang['setting_seodomains_user_id_desc'] = 'Необязательно, будет заполнен автоматически при первом добавлении домена';
$_lang['setting_seodomains_cyrillic_domain'] = 'Кириллический домен?';
$_lang['setting_seodomains_city_fields'] = 'Поля таблицы';