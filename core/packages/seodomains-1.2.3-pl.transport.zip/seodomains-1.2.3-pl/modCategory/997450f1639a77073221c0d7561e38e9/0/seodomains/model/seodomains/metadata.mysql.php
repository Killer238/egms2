<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'SeodomainsCity',
    1 => 'SeodomainsMorefields',
    2 => 'SeodomainsResource',
  ),
);