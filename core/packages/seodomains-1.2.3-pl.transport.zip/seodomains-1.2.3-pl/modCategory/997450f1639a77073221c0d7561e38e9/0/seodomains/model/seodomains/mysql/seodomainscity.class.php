<?php
require_once (dirname(__DIR__) . '/seodomainscity.class.php');
class SeodomainsCity_mysql extends SeodomainsCity {}