<?php
require_once (dirname(__DIR__) . '/seodomainsmorefields.class.php');
class SeodomainsMorefields_mysql extends SeodomainsMorefields {}