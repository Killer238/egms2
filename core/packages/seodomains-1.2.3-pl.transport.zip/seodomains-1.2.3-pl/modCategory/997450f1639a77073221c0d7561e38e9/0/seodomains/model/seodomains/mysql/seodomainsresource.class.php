<?php
require_once (dirname(__DIR__) . '/seodomainsresource.class.php');
class SeodomainsResource_mysql extends SeodomainsResource {}