<?php
class SeodomainsCity extends xPDOSimpleObject {}