<?php
class SeodomainsMorefields extends xPDOSimpleObject {}