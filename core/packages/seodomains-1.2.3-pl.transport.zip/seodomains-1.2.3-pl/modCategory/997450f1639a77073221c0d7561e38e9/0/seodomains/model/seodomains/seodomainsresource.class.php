<?php
class SeodomainsResource extends xPDOSimpleObject {}