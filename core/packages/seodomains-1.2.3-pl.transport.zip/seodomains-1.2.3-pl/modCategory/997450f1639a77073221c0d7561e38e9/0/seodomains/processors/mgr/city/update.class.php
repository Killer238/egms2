<?php
class SeodomainsCityUpdateProcessor extends modObjectUpdateProcessor {
    public $classKey = 'SeodomainsCity';
    
    /**
     * var modX
     */
}

return "SeodomainsCityUpdateProcessor";