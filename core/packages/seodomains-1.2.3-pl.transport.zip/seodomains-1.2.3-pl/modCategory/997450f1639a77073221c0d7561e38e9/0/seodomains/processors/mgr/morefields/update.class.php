<?php
class SeodomainsMorefieldsUpdateProcessor extends modObjectUpdateProcessor {
    public $classKey = 'SeodomainsMorefields';
}

return "SeodomainsMorefieldsUpdateProcessor";