<?php
class SeodomainsResourceUpdateProcessor extends modObjectUpdateProcessor {
    public $classKey = 'SeodomainsResource';
}

return "SeodomainsResourceUpdateProcessor";