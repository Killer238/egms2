--------------------
SeoFilter - convenient control of friendly URL, meta tags and text generation
--------------------
Author: Evgeniy Sheronov <webrush@bk.ru>
--------------------

SeoFilter for Minishop2 & mSearch2 and not only for MODX Revolution.

The articles about SeoFilter:
https://modx.pro/components/12921/
https://modx.pro/components/13407/
https://modx.pro/components/14899/
https://modx.pro/components/15476/
https://modx.pro/components/17313/

Full Documentation: https://docs.modx.pro/komponentyi/seofilter
Demo: http://s9767.h8.modhost.pro

Possible additional paid modifications for a specific project.