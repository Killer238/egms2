<?php
require_once (dirname(__DIR__) . '/sfdictionary.class.php');
class sfDictionary_mysql extends sfDictionary {}