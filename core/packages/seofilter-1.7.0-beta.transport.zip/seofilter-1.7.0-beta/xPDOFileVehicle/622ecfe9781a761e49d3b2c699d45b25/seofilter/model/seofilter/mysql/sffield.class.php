<?php
require_once (dirname(__DIR__) . '/sffield.class.php');
class sfField_mysql extends sfField {}