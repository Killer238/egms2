<?php
require_once (dirname(__DIR__) . '/sffieldids.class.php');
class sfFieldIds_mysql extends sfFieldIds {}