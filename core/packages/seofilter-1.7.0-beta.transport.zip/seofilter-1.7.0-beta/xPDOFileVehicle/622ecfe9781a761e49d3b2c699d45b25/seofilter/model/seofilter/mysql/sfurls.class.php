<?php
require_once (dirname(__DIR__) . '/sfurls.class.php');
class sfUrls_mysql extends sfUrls {}